# City Line Drawing Wallpapers

A collection of 61 stylized gray line drawing wallpapers featuring city skylines and landmarks, designed for iOS and iPad devices.

## Specifications

- **Dimensions**: 1290 x 2796 pixels (iPhone 15 Pro Max / iPad compatible)
- **Style**: Minimalist gray line art on white background
- **Format**: PNG

## US State Major Cities (50)

| State | City | Filename |
|-------|------|----------|
| Alabama | Birmingham | birmingham_alabama.png |
| Alaska | Anchorage | anchorage_alaska.png |
| Arizona | Phoenix | phoenix_arizona.png |
| Arkansas | Little Rock | little_rock_arkansas.png |
| California | Los Angeles | los_angeles_california.png |
| Colorado | Denver | denver_colorado.png |
| Connecticut | Bridgeport | bridgeport_connecticut.png |
| Delaware | Wilmington | wilmington_delaware.png |
| Florida | Jacksonville | jacksonville_florida.png |
| Georgia | Atlanta | atlanta_georgia.png |
| Hawaii | Honolulu | honolulu_hawaii.png |
| Idaho | Boise | boise_idaho.png |
| Illinois | Chicago | chicago_illinois.png |
| Indiana | Indianapolis | indianapolis_indiana.png |
| Iowa | Des Moines | des_moines_iowa.png |
| Kansas | Wichita | wichita_kansas.png |
| Kentucky | Louisville | louisville_kentucky.png |
| Louisiana | New Orleans | new_orleans_louisiana.png |
| Maine | Portland | portland_maine.png |
| Maryland | Baltimore | baltimore_maryland.png |
| Massachusetts | Boston | boston_massachusetts.png |
| Michigan | Detroit | detroit_michigan.png |
| Minnesota | Minneapolis | minneapolis_minnesota.png |
| Mississippi | Jackson | jackson_mississippi.png |
| Missouri | Kansas City | kansas_city_missouri.png |
| Montana | Billings | billings_montana.png |
| Nebraska | Omaha | omaha_nebraska.png |
| Nevada | Las Vegas | las_vegas_nevada.png |
| New Hampshire | Manchester | manchester_new_hampshire.png |
| New Jersey | Newark | newark_new_jersey.png |
| New Mexico | Albuquerque | albuquerque_new_mexico.png |
| New York | New York City | new_york_city.png |
| North Carolina | Charlotte | charlotte_north_carolina.png |
| North Dakota | Fargo | fargo_north_dakota.png |
| Ohio | Columbus | columbus_ohio.png |
| Oklahoma | Oklahoma City | oklahoma_city_oklahoma.png |
| Oregon | Portland | portland_oregon.png |
| Pennsylvania | Philadelphia | philadelphia_pennsylvania.png |
| Rhode Island | Providence | providence_rhode_island.png |
| South Carolina | Charleston | charleston_south_carolina.png |
| South Dakota | Sioux Falls | sioux_falls_south_dakota.png |
| Tennessee | Nashville | nashville_tennessee.png |
| Texas | Houston | houston_texas.png |
| Utah | Salt Lake City | salt_lake_city_utah.png |
| Vermont | Burlington | burlington_vermont.png |
| Virginia | Virginia Beach | virginia_beach_virginia.png |
| Washington | Seattle | seattle_washington.png |
| West Virginia | Charleston | charleston_west_virginia.png |
| Wisconsin | Milwaukee | milwaukee_wisconsin.png |
| Wyoming | Cheyenne | cheyenne_wyoming.png |

## Expo Team Cities (11)

| City | Country | Notable Team Members | Filename |
|------|---------|---------------------|----------|
| Kraków | Poland | Stanisław Chmiela, Tomasz Sapeta, Software Mansion team | krakow_poland.png |
| London | UK | Kadi Kraman, Phil Pluckthun | london_uk.png |
| Vancouver | Canada | Brent Vatne | vancouver_canada.png |
| Taipei | Taiwan | Kudo Chien | taipei_taiwan.png |
| Oslo | Norway | Christian Falch | oslo_norway.png |
| Amsterdam | Netherlands | Cedric van Putten | amsterdam_netherlands.png |
| Florianópolis | Brazil | Gabriel Donadel | florianopolis_brazil.png |
| Delhi | India | Aman Mittal | delhi_india.png |
| Frankfurt | Germany | Hirbod Mirjavadi | frankfurt_germany.png |
| Prague | Czech Republic | Vojtech Novak | prague_czech_republic.png |
| Palo Alto | California, USA | Charlie Cheever, James Ide (HQ) | palo_alto_california.png |

## Usage

These wallpapers are designed to be subtle and blend into the background. They work well as:
- iPhone lock screen or home screen wallpapers
- iPad wallpapers
- Desktop backgrounds

The content is positioned in the lower portion of the image to accommodate iOS clock and notification widgets.
